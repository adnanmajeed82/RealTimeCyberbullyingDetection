from flask import Flask, request, jsonify, render_template
import pandas as pd
import re
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import nltk

# Download VADER lexicon if not already downloaded
nltk.download('vader_lexicon')

app = Flask(__name__)

# ================== Step 1: Data Preparation and Model Training ==================

# Load the dataset
data = pd.read_csv('cyberbullying_dataset.csv')

# Print the columns to confirm the structure
print(data.columns)

# Preprocessing function for text
def preprocess_text(text):
    """
    Function to clean and preprocess the text data.
    - Removes links, special characters, and lowers the text.
    """
    if isinstance(text, str):  # Check if the input is a string
        text = re.sub(r"http\S+", "", text)  # Remove URLs
        text = re.sub(r"[^a-zA-Z\s]", "", text)  # Remove special characters, numbers
        text = text.lower().strip()  # Convert to lowercase and remove leading/trailing spaces
        return text
    else:
        return ""  # Return empty string for non-string inputs

# Apply preprocessing to the text data in the 'Text' column
data['processed_text'] = data['Text'].apply(preprocess_text)

# Encode the target labels ('oh_label' column for cyberbullying detection)
label_encoder = LabelEncoder()
data['label'] = label_encoder.fit_transform(data['oh_label'])

# Features (processed text) and target (cyberbullying label)
X = data['processed_text']
y = data['label']

# Vectorize text using TF-IDF
vectorizer = TfidfVectorizer(max_features=5000)
X_vectorized = vectorizer.fit_transform(X)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_vectorized, y, test_size=0.2, random_state=42)

# Train the Naive Bayes model
model = MultinomialNB()
model.fit(X_train, y_train)

# Evaluate the model (optional)
y_pred = model.predict(X_test)
print(f"Naive Bayes Accuracy: {accuracy_score(y_test, y_pred)}")

# Save the model and vectorizer
joblib.dump(model, 'cyberbullying_nb_model.pkl')
joblib.dump(vectorizer, 'tfidf_vectorizer.pkl')

# Load saved model and vectorizer
model = joblib.load('cyberbullying_nb_model.pkl')
vectorizer = joblib.load('tfidf_vectorizer.pkl')

# Initialize VADER Sentiment Analyzer
sid = SentimentIntensityAnalyzer()

# ================== Step 2: Flask App for Prediction ==================

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get user input from form
    user_input = request.form['message']
    
    # Preprocess the input
    processed_input = preprocess_text(user_input)
    
    # Vectorize the input for the Naive Bayes model
    vectorized_input = vectorizer.transform([processed_input])
    
    # Predict cyberbullying
    prediction = model.predict(vectorized_input)
    
    # Perform sentiment analysis
    sentiment_scores = sid.polarity_scores(user_input)
    if sentiment_scores['compound'] >= 0.05:
        sentiment = "Positive"
    elif sentiment_scores['compound'] <= -0.05:
        sentiment = "Negative"
    else:
        sentiment = "Neutral"
    
    # Map prediction to category
    if prediction[0] == 1:
        result = "Cyberbullying Detected"
    else:
        result = "No Cyberbullying Detected"
    
    # Return results as JSON
    return jsonify(result=result, sentiment=sentiment)

# ================== Step 3: Running the Flask App ==================

if __name__ == '__main__':
    app.run(debug=True)
