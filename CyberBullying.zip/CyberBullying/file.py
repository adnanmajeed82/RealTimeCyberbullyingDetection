import pandas as pd

# Load the dataset
data = pd.read_csv('cyberbullying_dataset.csv')

# Print columns to check the actual column names
print(data.columns)  # Add this line to see the exact column names

# Assuming the correct column name is 'text' or adjust based on the print result
data['processed_text'] = data['text'].apply(preprocess_text)
